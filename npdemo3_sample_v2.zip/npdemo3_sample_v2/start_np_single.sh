#! /bin/sh

trap cleanup 0 1 2 3 6

cleanup()
{
  rm -rf "/tmp/np_single/$WORKING_DIR"
}

cd /tmp/np_single/ || exit

PORT=$(python3 port.py)
WORKING_DIR="working_dir_${PORT}"

mkdir "$WORKING_DIR"
cp -r "working_dir_template/"* "$WORKING_DIR"

if cd "$WORKING_DIR"; then
  if [ -x ./np_single_golden ]; then
    echo "A chat room (np_single) is listening on \"$(hostname)\" with port \"$PORT\""
    ./np_single_golden "$PORT"
  else
    echo "Either np_single_golden cannot be found or it is not and executable..."
    exit 1
  fi
else
  echo "Cannot change to the directory \"np_single\""
  exit 1
fi
