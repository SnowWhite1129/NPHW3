#! /bin/sh

# This is the demo script for NP project 3. You should use this script to automatically compile and make the executables
# as the spec says.
# If nothing goes wrong, some urls will shown and you should manually use a browser to visit them.

# Print a string with color modified.
# e.g., $ ERROR "This is an error".
ERROR() {
  echo -e "\e[91m[ERROR] $1\e[39m"
}

# Abbreviate from SUCCESS
SUCC() {
  echo -e "\e[92m[SUCC] $1\e[39m"
}

INFO() {
  echo -e "\e[93m[INFO] $1\e[39m"
}

PROJECT_NAME=npdemo3

# If the demo working directory already exists (probably because you have executed it before), remove it.
if [ -f ~/.$PROJECT_NAME ]; then
  INFO "Removing previously created demo directory."
  rm -rf "$(cat ~/.$PROJECT_NAME)"
  rm -rf "$HOME/.$PROJECT_NAME"
fi

# Define variables
NP_SCRIPT_PATH=$(readlink -f "$0")
NP_SCRIPT_DIR=$(dirname "$NP_SCRIPT_PATH")
DEMO_DIR=$(mktemp -d -p /tmp ${PROJECT_NAME}.XXXX)

chmod 700 "$DEMO_DIR"

# Create a hidden file and write the demo directory's path into it.
cat >~/.$PROJECT_NAME <<EOF
$DEMO_DIR
EOF

# Fetching student id, by args or by searching
if [[ -n "$1" ]]; then
  STUDENT_ID=$1
else
  STUDENT_ID=$(ldapsearch -LLLx "uid=$USER" csid | tail -n 2 | head -n 1 | cut -d " " -f 2)
fi

# Copy student's source code and utilities to the demo directory.
cp -r "$NP_SCRIPT_DIR/src/$STUDENT_ID" "$DEMO_DIR/src"
mkdir "$DEMO_DIR/working_dir" && cp -r "$NP_SCRIPT_DIR/working_dir/"* "$DEMO_DIR/working_dir"
cp -r "$NP_SCRIPT_DIR/port.py" "$DEMO_DIR"

# Copy files to default-http_server directory.
mkdir -p "$HOME/public_html" && cp -r "$NP_SCRIPT_DIR/working_dir/"* "$HOME/public_html"

# Change directory into the demo directory.
# Compile, and let the student's programs do it's work.
if cd "$DEMO_DIR"; then
  INFO "Compiling..."
  if (make -C "$DEMO_DIR/src"); then
    SUCC "Compilation completed!"
  else
    ERROR "Your project cannot be compiled by make"
    exit 1
  fi

  if ! (cp src/console.cgi src/http_server "$DEMO_DIR/working_dir"); then
    ERROR "Failed to copy the generated executables to the demo directory (Did you name them right?)."
    exit 1
  fi

  if ! (cp src/console.cgi "$HOME/public_html"); then
    ERROR "Cannot copy your console.cgi to public_html (Did you name it right?)."
    exit 1
  fi

  HTTP_SERVER_PORT=$(python3 port.py)
  SUCC "Your simplified http_server is listening at port: $HTTP_SERVER_PORT"
  echo ""
  INFO "Part 1-1: console.cgi"
  echo "  *  (25%)    http://$(hostname)/~$(whoami)/panel.cgi"
  echo ""
  INFO "Part 1-2: http_server"
  echo "  *  (5%)     http://$(hostname):$HTTP_SERVER_PORT/printenv.cgi?pj3_score=100"
  echo "     (5%)     http://$(hostname):$HTTP_SERVER_PORT/hello.cgi"
  echo "     (5%)     http://$(hostname):$HTTP_SERVER_PORT/welcome.cgi"
  echo ""
  INFO "Part 1-3: combined"
  echo "  *  (10%)    http://$(hostname):$HTTP_SERVER_PORT/panel.cgi"
  cd working_dir || exit 1
  env -i ./http_server "$HTTP_SERVER_PORT"

else
  ERROR "Cannot change to the demo directory!"
  exit
fi
