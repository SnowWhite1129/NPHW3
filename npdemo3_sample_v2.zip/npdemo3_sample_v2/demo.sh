#! /bin/sh

if [ -n "$(tmux ls | grep pj3_demo)" ]; then
  tmux kill-session -t "pj3_demo"
fi
tmux new-session -d -s "pj3_demo"
tmux split-window -v -p 60
tmux select-pane -t 0
tmux send "cd $(dirname "$(readlink -f "$0")"); ./start_np_singles.py" ENTER
tmux select-pane -t 1
tmux send "cd $(dirname "$(readlink -f "$0")"); ./start_http_server.sh $1" ENTER
tmux attach-session -t "pj3_demo"
